# Author : Anwesha Biswas

## Task 1 : Prediction using Supervised Machine Learning

### GRIP @ The Sparks Foundation

In this regression, we predict the percentage of marks that a student is expected to score based on the no. of study hours. This is a simple linear regression task as it involves just 2 variables.

### Technical Stack: Scikit Learn, Numpy Array, Pandas, Matplotlib


```python
#Importing the required libraries
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
```

### Step 1 - Reading data from the Source


```python
#Reading data from remote link
url = "https://raw.githubusercontent.com/AdiPersonalWorks/Random/master/student_scores%20-%20student_scores.csv"
s_data = pd.read_csv(url)
print("Data import successful")

s_data.head(25)
```

    Data import successful
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.5</td>
      <td>20</td>
    </tr>
    <tr>
      <th>6</th>
      <td>9.2</td>
      <td>88</td>
    </tr>
    <tr>
      <th>7</th>
      <td>5.5</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8.3</td>
      <td>81</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2.7</td>
      <td>25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>7.7</td>
      <td>85</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5.9</td>
      <td>62</td>
    </tr>
    <tr>
      <th>12</th>
      <td>4.5</td>
      <td>41</td>
    </tr>
    <tr>
      <th>13</th>
      <td>3.3</td>
      <td>42</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1.1</td>
      <td>17</td>
    </tr>
    <tr>
      <th>15</th>
      <td>8.9</td>
      <td>95</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1.9</td>
      <td>24</td>
    </tr>
    <tr>
      <th>18</th>
      <td>6.1</td>
      <td>67</td>
    </tr>
    <tr>
      <th>19</th>
      <td>7.4</td>
      <td>69</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2.7</td>
      <td>30</td>
    </tr>
    <tr>
      <th>21</th>
      <td>4.8</td>
      <td>54</td>
    </tr>
    <tr>
      <th>22</th>
      <td>3.8</td>
      <td>35</td>
    </tr>
    <tr>
      <th>23</th>
      <td>6.9</td>
      <td>76</td>
    </tr>
    <tr>
      <th>24</th>
      <td>7.8</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
</div>



### Step 2 - Input Data Visualization


```python
#Ploting the distribution of scores
s_data.plot(x='Hours', y='Scores', style = 'o')
plt.title('Percentage scored per hour')
plt.xlabel('Hours')
plt.ylabel('Score Percentage')
plt.show()
```


    
![png](output_9_0.png)
    


This graphs shows the positive linear relation that exists between the number of hours studied and percentage of score

### Step 3 - Data Preprocessing


```python
x = s_data.iloc[:,:-1].values
y = s_data.iloc[:, 1].values
```

### Step 4 - Model Training

Here we split the data into training and testing sets and finally train the algorithm.


```python
x_train, x_test, y_train, y_test = train_test_split (x, y, test_size=0.2, random_state= 0)
regressor= LinearRegression()
regressor.fit(x_train.reshape(-1,1), y_train)

print("Training completed")
```

    Training completed
    

### Step 5 - Plotting the line of Regression


```python
#Plotting the regression line
line = regressor.coef_*x+regressor.intercept_

#Plotting for the test data
plt.scatter(x,y)
plt.plot(x, line, color='red')
plt.show()
```


    
![png](output_17_0.png)
    


### Step 6 - Making Predictions and Plotting the Comparisons


```python
#Testing data
print(x_test)

#Model Prediction
y_pred = regressor.predict(x_test)
```

    [[1.5]
     [3.2]
     [7.4]
     [2.5]
     [5.9]]
    


```python
#Comparison between Actual and Predicted
t = pd.DataFrame({'Actual': y_test,'Predicted': y_pred})
t
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20</td>
      <td>16.884145</td>
    </tr>
    <tr>
      <th>1</th>
      <td>27</td>
      <td>33.732261</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69</td>
      <td>75.357018</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30</td>
      <td>26.794801</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>60.491033</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Estimating training and test score
print("Training Score:", regressor.score(x_train,y_train))
print("Test Score:", regressor.score(x_test,y_test))
```

    Training Score: 0.9515510725211552
    Test Score: 0.9454906892105354
    


```python
#Plotting to show the difference between Actual and Predicted

t.plot(kind='bar', figsize=(6,6))
plt.show()
```


    
![png](output_22_0.png)
    



```python
#Testing the model with given info
hours= 9.25
test = np.array([hours])
test = test.reshape(1,-1)
new_pred = regressor.predict(test)
print("Number of Hours = {}".format(hours))
print("Predicted Score = {}".format(new_pred[0]))
```

    Number of Hours = 9.25
    Predicted Score = 93.69173248737539
    

### Step 7 - Evaluation of the Model


```python
from sklearn import metrics
print('Mean Absolute Error:', metrics.mean_absolute_error(y_test,y_pred))
print('Mean Squared Error:', metrics.mean_squared_error(y_test,y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test,y_pred)))
print('R-2:', metrics.r2_score(y_test,y_pred))
```

    Mean Absolute Error: 4.183859899002982
    Mean Squared Error: 21.598769307217456
    Root Mean Squared Error: 4.647447612100373
    R-2: 0.9454906892105354
    

R-2 gives the score of the model fit and here we have R-2 =  0.9454906892105354 which is a good score for our model

### Conclusion
#### I was successfully able to carry out the Prediction using Supervised ML task and I was able to evaluate the model's performance.

### Thank you.


```python

```
